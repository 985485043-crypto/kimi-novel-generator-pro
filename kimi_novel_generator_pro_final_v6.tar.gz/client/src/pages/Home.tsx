import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Download, History, List, Plus, CheckCircle2, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const NOVEL_TYPES = [
  { value: "urban_romance", label: "都市言情" },
  { value: "abusive_love", label: "虐恋" },
  { value: "family", label: "家庭" },
  { value: "mystery", label: "悬疑" },
  { value: "sweet_pet", label: "甜宠" },
] as const;

export default function Home() {
  // 临时移除 useAuth 以绕过 URL 错误
  const user = { id: 1 }; // 模拟登录用户
  const [apiKey, setApiKey] = useState("");
  const [titlesText, setTitlesText] = useState("");
  const [novelType, setNovelType] = useState<typeof NOVEL_TYPES[number]["value"]>("urban_romance");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedBatchId, setSelectedBatchId] = useState<number | null>(null);

  // tRPC Hooks
  const submitBatchMutation = trpc.novel.submitBatch.useMutation();
  const { data: batches, refetch: refetchBatches } = trpc.novel.getBatches.useQuery(undefined, {
    refetchInterval: 5000, 
  });
  const { data: batchDetails } = trpc.novel.getBatchDetails.useQuery(
    { batchId: selectedBatchId! },
    { enabled: selectedBatchId !== null, refetchInterval: 3000 }
  );

  const handleStartBatch = async () => {
    if (!apiKey.trim()) return toast.error("请输入 API Key");
    const titles = titlesText.split("\n").map(t => t.trim()).filter(t => t.length > 0);
    if (titles.length === 0) return toast.error("请输入至少一个标题");
    if (titles.length > 100) return toast.error("单次最多支持 100 个标题");

    setIsSubmitting(true);
    try {
      const result = await submitBatchMutation.mutateAsync({
        titles,
        apiKey: apiKey.trim(),
        type: novelType,
      });

      if (result.success) {
        toast.success(`成功提交 ${result.count} 个任务`);
        setTitlesText("");
        refetchBatches();
        if (result.batchId) setSelectedBatchId(result.batchId);
      } else {
        toast.error(result.error || "提交失败");
      }
    } catch (err) {
      toast.error("提交过程中发生错误");
    } finally {
      setIsSubmitting(false);
    }
  };

  const downloadNovel = (novel: any) => {
    const element = document.createElement("a");
    const content = `《${novel.title}》\n\n大纲：\n${novel.outline}\n\n正文：\n${novel.content}`;
    element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(content));
    element.setAttribute("download", `${novel.title}.txt`);
    element.click();
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-slate-900">Kimi 批量小说生成器 Pro</h1>
          <p className="text-slate-500 mt-2">支持多人高并发，单次最高 100 篇批量创作</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-4 space-y-6">
            <Card className="p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Plus className="w-5 h-5" /> 新建任务
              </h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Moonshot API Key</label>
                  <Input 
                    type="password" 
                    placeholder="sk-..." 
                    value={apiKey} 
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">创作类型</label>
                  <div className="grid grid-cols-2 gap-2">
                    {NOVEL_TYPES.map(t => (
                      <Button
                        key={t.value}
                        variant={novelType === t.value ? "default" : "outline"}
                        size="sm"
                        onClick={() => setNovelType(t.value)}
                      >
                        {t.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">小说标题 (每行一个，最多100个)</label>
                  <Textarea 
                    placeholder="标题1&#10;标题2&#10;标题3..." 
                    rows={10}
                    value={titlesText}
                    onChange={(e) => setTitlesText(e.target.value)}
                  />
                </div>

                <Button 
                  className="w-full" 
                  onClick={handleStartBatch} 
                  disabled={isSubmitting}
                >
                  {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : null}
                  开始批量生成
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <History className="w-5 h-5" /> 历史批次
              </h2>
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {batches?.map(batch => (
                  <div 
                    key={batch.id}
                    onClick={() => setSelectedBatchId(batch.id)}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedBatchId === batch.id ? "bg-blue-50 border-blue-200" : "hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <span className="font-medium text-sm truncate">{batch.name}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                        batch.status === "completed" ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700"
                      }`}>
                        {batch.status}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center gap-2 text-xs text-slate-500">
                      <span>进度: {batch.completedCount + batch.failedCount} / {batch.totalCount}</span>
                      <div className="flex-1 h-1 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-blue-500" 
                          style={{ width: `${(batch.completedCount / batch.totalCount) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <div className="lg:col-span-8">
            {selectedBatchId ? (
              <Card className="p-6 h-full">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold">批次详情: {batchDetails?.batch?.name}</h2>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedBatchId(null)}>关闭</Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {batchDetails?.novels.map(novel => (
                    <div key={novel.id} className="p-4 border rounded-xl bg-white shadow-sm">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-slate-800 truncate flex-1">{novel.title}</h3>
                        {novel.status === "completed" ? (
                          <CheckCircle2 className="w-5 h-5 text-green-500" />
                        ) : novel.status === "failed" ? (
                          <AlertCircle className="w-5 h-5 text-red-500" />
                        ) : (
                          <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
                        )}
                      </div>
                      
                      <div className="text-xs text-slate-500 mb-3 space-y-1">
                        <p>状态: {novel.status}</p>
                        <p>字数: {novel.totalChars} / 15000</p>
                      </div>

                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          disabled={novel.status !== "completed"}
                          onClick={() => downloadNovel(novel)}
                        >
                          <Download className="w-4 h-4 mr-1" /> 下载
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 bg-slate-100 rounded-3xl border-2 border-dashed">
                <List className="w-16 h-16 mb-4 opacity-20" />
                <p>从左侧选择一个批次查看详情，或创建新任务</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
