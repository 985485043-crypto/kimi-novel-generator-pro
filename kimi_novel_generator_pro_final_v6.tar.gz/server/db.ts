import { createClient } from "@libsql/client";
import path from 'path';

let _client: any = null;

export async function getClient() {
  if (!_client) {
    _client = createClient({
      url: `file:${path.join(process.cwd(), "local.db")}`,
    });
    
    // 初始化表结构
    await _client.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        openId TEXT UNIQUE,
        name TEXT,
        email TEXT,
        role TEXT DEFAULT 'user',
        loginMethod TEXT,
        lastSignedIn INTEGER,
        createdAt INTEGER,
        updatedAt INTEGER
      );
    `);
    await _client.execute(`
      CREATE TABLE IF NOT EXISTS batches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId INTEGER,
        name TEXT,
        totalCount INTEGER DEFAULT 0,
        completedCount INTEGER DEFAULT 0,
        failedCount INTEGER DEFAULT 0,
        status TEXT DEFAULT 'pending',
        createdAt INTEGER,
        updatedAt INTEGER
      );
    `);
    await _client.execute(`
      CREATE TABLE IF NOT EXISTS novels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId INTEGER,
        batchId INTEGER,
        title TEXT,
        type TEXT,
        outline TEXT,
        content TEXT,
        status TEXT DEFAULT 'pending',
        totalChars INTEGER DEFAULT 0,
        currentSegment INTEGER DEFAULT 0,
        errorMessage TEXT,
        createdAt INTEGER,
        updatedAt INTEGER,
        completedAt INTEGER
      );
    `);
  }
  return _client;
}

export async function createBatch(data: any) {
  const client = await getClient();
  const now = Date.now();
  const result = await client.execute({
    sql: `INSERT INTO batches (userId, name, totalCount, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)`,
    args: [data.userId, data.name, data.totalCount, data.status || 'pending', now, now]
  });
  return Number(result.lastInsertRowid);
}

export async function createNovel(data: any) {
  const client = await getClient();
  const now = Date.now();
  const result = await client.execute({
    sql: `INSERT INTO novels (userId, batchId, title, type, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    args: [data.userId, data.batchId, data.title, data.type, data.status || 'pending', now, now]
  });
  return Number(result.lastInsertRowid);
}

export async function updateBatchStatus(id: number, updates: any) {
  const client = await getClient();
  const keys = Object.keys(updates);
  const setClause = keys.map(k => `${k} = ?`).join(', ');
  await client.execute({
    sql: `UPDATE batches SET ${setClause}, updatedAt = ? WHERE id = ?`,
    args: [...Object.values(updates), Date.now(), id]
  });
}

export async function updateNovelStatus(id: number, status: string, updates: any = {}) {
  const client = await getClient();
  const extraKeys = Object.keys(updates);
  let sql = `UPDATE novels SET status = ?, updatedAt = ?`;
  const args: any[] = [status, Date.now()];
  
  if (status === 'completed') {
    sql += `, completedAt = ?`;
    args.push(Date.now());
  }
  
  extraKeys.forEach(k => {
    sql += `, ${k} = ?`;
    args.push(updates[k]);
  });
  
  sql += ` WHERE id = ?`;
  args.push(id);
  
  await client.execute({ sql, args });
}

export async function getBatchById(id: number) {
  const client = await getClient();
  const result = await client.execute({
    sql: `SELECT * FROM batches WHERE id = ?`,
    args: [id]
  });
  return result.rows[0];
}

export async function getNovelsByBatchId(batchId: number) {
  const client = await getClient();
  const result = await client.execute({
    sql: `SELECT * FROM novels WHERE batchId = ? ORDER BY id ASC`,
    args: [batchId]
  });
  return result.rows;
}

export async function getUserBatches(userId: number) {
  const client = await getClient();
  const result = await client.execute({
    sql: `SELECT * FROM batches WHERE userId = ? ORDER BY createdAt DESC`,
    args: [userId]
  });
  return result.rows;
}

export async function getNovelById(id: number) {
  const client = await getClient();
  const result = await client.execute({
    sql: `SELECT * FROM novels WHERE id = ?`,
    args: [id]
  });
  return result.rows[0];
}

export async function getUserNovels(userId: number) {
  const client = await getClient();
  const result = await client.execute({
    sql: `SELECT * FROM novels WHERE userId = ? ORDER BY createdAt DESC`,
    args: [userId]
  });
  return result.rows;
}

export async function deleteNovel(id: number, userId: number) {
  const client = await getClient();
  await client.execute({
    sql: `DELETE FROM novels WHERE id = ? AND userId = ?`,
    args: [id, userId]
  });
}

export async function upsertUser(user: any) {
  const client = await getClient();
  const now = Date.now();
  await client.execute({
    sql: `INSERT INTO users (openId, name, email, role, loginMethod, lastSignedIn, createdAt, updatedAt) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(openId) DO UPDATE SET 
          name = excluded.name, 
          email = excluded.email, 
          lastSignedIn = excluded.lastSignedIn, 
          updatedAt = excluded.updatedAt`,
    args: [user.openId, user.name, user.email, user.role || 'user', user.loginMethod, now, now, now]
  });
}

export async function getUserByOpenId(openId: string) {
  const client = await getClient();
  const result = await client.execute({
    sql: `SELECT * FROM users WHERE openId = ?`,
    args: [openId]
  });
  return result.rows[0];
}

// 兼容 Drizzle 的 getDb 接口，虽然现在不直接使用它
export async function getDb() {
  return null;
}
