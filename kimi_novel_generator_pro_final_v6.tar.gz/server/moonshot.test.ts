import { describe, it, expect, vi, beforeEach } from "vitest";
import {
  createMoonshotClient,
  getGenerationConfig,
  shouldContinueGenerating,
} from "./moonshot";

describe("Moonshot Module", () => {
  describe("createMoonshotClient", () => {
    it("should throw error when API key is empty", () => {
      expect(() => createMoonshotClient("")).toThrow(
        "Moonshot API Key 不能为空"
      );
    });

    it("should create client with valid API key", () => {
      const client = createMoonshotClient("sk-test-key");
      expect(client).toBeDefined();
      expect(client.apiKey).toBe("sk-test-key");
      expect(client.baseURL).toBe("https://api.moonshot.cn/v1");
    });
  });

  describe("getGenerationConfig", () => {
    it("should return correct generation configuration", () => {
      const config = getGenerationConfig();
      
      expect(config.targetChars).toBe(15000);
      expect(config.segmentChars).toBe(2500);
      expect(config.segmentTokens).toBeGreaterThan(0);
      expect(config.historySegmentsToKeep).toBe(2);
    });

    it("should have consistent configuration values", () => {
      const config = getGenerationConfig();
      
      // segmentTokens 应该大约是 segmentChars 的 1.5 倍
      expect(config.segmentTokens).toBeGreaterThanOrEqual(
        Math.floor(config.segmentChars * 1.5)
      );
      expect(config.segmentTokens).toBeLessThanOrEqual(
        Math.ceil(config.segmentChars * 1.5) + 1
      );
    });
  });

  describe("shouldContinueGenerating", () => {
    it("should return true when current length is less than target", () => {
      expect(shouldContinueGenerating(5000)).toBe(true);
      expect(shouldContinueGenerating(10000)).toBe(true);
      expect(shouldContinueGenerating(14999)).toBe(true);
    });

    it("should return false when current length reaches target", () => {
      expect(shouldContinueGenerating(15000)).toBe(false);
      expect(shouldContinueGenerating(15001)).toBe(false);
      expect(shouldContinueGenerating(20000)).toBe(false);
    });

    it("should return true at zero length", () => {
      expect(shouldContinueGenerating(0)).toBe(true);
    });
  });
});
