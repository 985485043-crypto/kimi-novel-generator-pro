import { OpenAI } from "openai";

/**
 * Moonshot AI 配置
 */
const MOONSHOT_BASE_URL = "https://api.moonshot.cn/v1";
const MODEL_NAME = "kimi-k2-turbo-preview";
const TARGET_CHARS = 15000;
const SEGMENT_CHARS = 2500;
const SEGMENT_TOKENS = Math.ceil(SEGMENT_CHARS * 1.5);
const HISTORY_SEGMENTS_TO_KEEP = 2;

/**
 * 初始化 Moonshot AI 客户端
 */
export function createMoonshotClient(apiKey: string) {
  if (!apiKey || apiKey.trim() === "") {
    throw new Error("Moonshot API Key 不能为空");
  }

  return new OpenAI({
    apiKey: apiKey.trim(),
    baseURL: MOONSHOT_BASE_URL,
    timeout: 120000,
    defaultHeaders: {
      "User-Agent": "Kimi-Novel-Generator/1.0",
    },
  });
}

/**
 * 调用 Moonshot API 进行文本生成
 */
export async function callMoonshotAPI(
  client: OpenAI,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  try {
    const response = await client.chat.completions.create({
      model: MODEL_NAME,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.85, // 略微提高随机性，增加文学色彩
      max_tokens: SEGMENT_TOKENS,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error("API 返回空内容");
    return content;
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : "未知错误";
    if (errorMsg.includes("401")) throw new Error("API Key 无效");
    if (errorMsg.includes("429")) throw new Error("请求频率过高");
    throw error;
  }
}

/**
 * 获取不同类型的提示词
 * 优化都市言情：增加张力、情感拉扯，保持合规
 */
function getTypePrompt(type: string): string {
  const typePrompts: Record<string, string> = {
    urban_romance: 
      "这是一部极具张力的都市言情小说。要求：\n" +
      "1. 情感拉扯：注重男女主之间的眼神交流、肢体接触的细微描写，营造暧昧氛围和宿命感。\n" +
      "2. 角色魅力：男主冷峻深沉、权势滔天但内心有柔软处；女主独立坚韧、聪慧过人，两人在职场或社交场上有精彩的博弈。\n" +
      "3. 氛围营造：通过环境、香气、光影描写来烘托情感，文字要优美且富有感染力。\n" +
      "4. 吸引力法则：可以有令人心跳加速的亲密互动描写（如拥抱、亲吻、耳语），但必须严格遵守合规要求：严禁任何色情、淫秽、生殖器官或隐私部位的直白表述，严禁任何违背公序良俗的内容。重点在于表现情感的爆发和心理的悸动，而非生理描写。",
    
    abusive_love: "这是一部情感极致的虐恋小说。要求：误会重重，爱恨交织，情感表达要具有冲击力，在绝望中寻找救赎。",
    family: "这是一部充满生活气息的家庭伦理小说。要求：细节真实，情感细腻，描写家庭成员间的矛盾与温情。",
    mystery: "这是一部逻辑严密的悬疑小说。要求：环环相扣，悬念迭起，氛围阴冷，真相出人意料。",
    sweet_pet: "这是一部高糖治愈的甜宠小说。要求：互动甜蜜，基调轻松，充满幸福感，让读者感到极度舒适。",
  };
  return typePrompts[type] || typePrompts.urban_romance;
}

/**
 * 生成故事大纲
 */
export async function generateOutline(
  client: OpenAI,
  title: string,
  type: string
): Promise<string> {
  const typePrompt = getTypePrompt(type);
  const systemPrompt =
    `你是一位顶尖的中文小说家，擅长创作引人入胜的长篇故事。${typePrompt}\n` +
    "你的任务是为一篇约 15000 字的小说设计一个结构严谨、冲突强烈的大纲。";

  const userPrompt =
    `请根据标题《${title}》，设计一个包含 6 到 8 个章节的详细大纲。大纲必须包括：\n` +
    "1. 核心冲突、情感主线和主题。\n" +
    "2. 每一章的标题和详细剧情梗概（包含关键转折和情感爆发点）。\n" +
    "3. 确保整体节奏感强，每一章都能吸引读者继续阅读。";

  return callMoonshotAPI(client, systemPrompt, userPrompt);
}

/**
 * 根据标题和大纲生成故事段落
 */
export async function generateSegment(
  client: OpenAI,
  title: string,
  outline: string,
  previousSegments: string[],
  segmentIndex: number,
  type: string
): Promise<string> {
  const typePrompt = getTypePrompt(type);
  const history = previousSegments.slice(-HISTORY_SEGMENTS_TO_KEEP).join("\n\n");

  const systemPrompt =
    `你是一位顶尖的中文小说家。${typePrompt}\n` +
    "你必须严格遵循大纲，确保内容与前文完美衔接，保持文风一致，情感饱满。" +
    `目标总字数 15000 字。请创作当前章节的内容，字数约 ${SEGMENT_CHARS} 字。`;

  const userPrompt =
    `小说标题：《${title}》\n` +
    `--- 详细大纲 ---\n${outline}\n` +
    `--- 前文回顾 ---\n${history || "(故事开始)"}\n` +
    `--- 创作指令 ---\n` +
    `请继续创作。要求：文字要有画面感，情感描写要深入人心。直接输出小说正文，不要包含任何标题或解释。`;

  let content = await callMoonshotAPI(client, systemPrompt, userPrompt);
  return content.replace(/^下一段内容：|^正文：/g, "").trim();
}

export function shouldContinueGenerating(currentLength: number): boolean {
  return currentLength < TARGET_CHARS;
}

export function getGenerationConfig() {
  return {
    targetChars: TARGET_CHARS,
    segmentChars: SEGMENT_CHARS,
    segmentTokens: SEGMENT_TOKENS,
    historySegmentsToKeep: HISTORY_SEGMENTS_TO_KEEP,
  };
}
