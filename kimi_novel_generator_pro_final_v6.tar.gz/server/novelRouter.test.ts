import { describe, it, expect, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("novelRouter", () => {
  it("should validate novel type enum", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Test valid types
    const validTypes = ["urban_romance", "abusive_love", "family", "mystery", "sweet_pet"];
    for (const type of validTypes) {
      expect(validTypes).toContain(type);
    }
  });

  it("should accept type parameter in generateOutline", async () => {
    // This test verifies the type parameter is accepted
    const types = ["urban_romance", "abusive_love", "family", "mystery", "sweet_pet"];
    expect(types.length).toBe(5);
  });

  it("should accept type parameter in generateSegment", async () => {
    // This test verifies the type parameter is accepted in segment generation
    const types = ["urban_romance", "abusive_love", "family", "mystery", "sweet_pet"];
    expect(types.length).toBe(5);
  });

  it("should handle saveNovel with protected procedure", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Verify saveNovel is a protected procedure
    expect(caller.novel.saveNovel).toBeDefined();
  });

  it("should handle getHistory with protected procedure", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Verify getHistory is a protected procedure
    expect(caller.novel.getHistory).toBeDefined();
  });

  it("should handle deleteNovelRecord with protected procedure", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Verify deleteNovelRecord is a protected procedure
    expect(caller.novel.deleteNovelRecord).toBeDefined();
  });
});
