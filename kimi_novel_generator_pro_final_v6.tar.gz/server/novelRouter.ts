import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { getGenerationConfig } from "./moonshot";
import { 
  getUserNovels, 
  deleteNovel, 
  createNovel, 
  createBatch, 
  getUserBatches, 
  getNovelsByBatchId,
  getBatchById,
  updateBatchStatus
} from "./db";
import { TaskProcessor } from "./queue";

// 临时将 protectedProcedure 替换为 publicProcedure 以绕过登录限制
const testProcedure = publicProcedure;

export const novelRouter = router({
  /**
   * 提交批量生成任务
   */
  submitBatch: testProcedure
    .input(z.object({
      titles: z.array(z.string().min(1)).min(1).max(100),
      apiKey: z.string().min(1),
      type: z.enum(["urban_romance", "abusive_love", "family", "mystery", "sweet_pet"]).default("urban_romance"),
    }))
    .mutation(async ({ input }) => {
      try {
        const userId = 1; // 模拟用户 ID
        const batchId = await createBatch({
          userId: userId,
          name: `批量生成 - ${new Date().toLocaleString()}`,
          totalCount: input.titles.length,
          status: "pending",
        });

        const novelIds: number[] = [];
        for (const title of input.titles) {
          const novelId = await createNovel({
            userId: userId,
            batchId: batchId,
            title: title,
            type: input.type,
            status: "pending",
          });
          novelIds.push(novelId);
        }

        (async () => {
          await updateBatchStatus(batchId, { status: "processing" });
          for (const novelId of novelIds) {
            await TaskProcessor.addToQueue(novelId, input.apiKey);
          }
        })();

        return {
          success: true,
          batchId,
          count: input.titles.length,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "提交失败",
        };
      }
    }),

  /**
   * 获取用户的批次列表
   */
  getBatches: testProcedure.query(async () => {
    return await getUserBatches(1);
  }),

  /**
   * 获取批次详情及所属小说
   */
  getBatchDetails: testProcedure
    .input(z.object({ batchId: z.number() }))
    .query(async ({ input }) => {
      const batch = await getBatchById(input.batchId);
      const novels = await getNovelsByBatchId(input.batchId);
      return { batch, novels };
    }),

  /**
   * 获取生成配置
   */
  getConfig: publicProcedure.query(() => {
    return getGenerationConfig();
  }),

  /**
   * 获取用户的小说历史记录
   */
  getHistory: testProcedure.query(async () => {
    try {
      const novels = await getUserNovels(1);
      return { success: true, novels };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "获取失败";
      return { success: false, error: errorMessage, novels: [] };
    }
  }),

  /**
   * 删除小说记录
   */
  deleteNovelRecord: testProcedure
    .input(z.object({
      novelId: z.number().int().positive(),
    }))
    .mutation(async ({ input }) => {
      try {
        await deleteNovel(input.novelId, 1);
        return { success: true };
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "删除失败";
        return { success: false, error: errorMessage };
      }
    }),
});
