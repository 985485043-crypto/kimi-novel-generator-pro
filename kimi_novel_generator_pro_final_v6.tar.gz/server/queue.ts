import { createMoonshotClient, generateOutline, generateSegment, getGenerationConfig } from "./moonshot";
import { updateNovelStatus, updateBatchStatus, getBatchById, getNovelById } from "./db";

/**
 * 任务处理器：管理并发和任务队列
 */
export class TaskProcessor {
  private static queue: { novelId: number; apiKey: string }[] = [];
  private static activeCount = 0;
  private static maxConcurrent = 5; // 最大并发 AI 调用数

  /**
   * 将任务添加到队列
   */
  static async addToQueue(novelId: number, apiKey: string) {
    this.queue.push({ novelId, apiKey });
    this.processNext();
  }

  private static async processNext() {
    if (this.activeCount >= this.maxConcurrent || this.queue.length === 0) {
      return;
    }

    const task = this.queue.shift();
    if (!task) return;

    this.activeCount++;
    this.runTask(task.novelId, task.apiKey).finally(() => {
      this.activeCount--;
      this.processNext();
    });

    // 尝试启动下一个任务
    this.processNext();
  }

  private static async runTask(novelId: number, apiKey: string) {
    console.log(`[Queue] Starting task for novel ${novelId}`);
    try {
      const novel = await getNovelById(novelId);
      if (!novel) return;

      const client = createMoonshotClient(apiKey);
      const config = getGenerationConfig();

      // 1. 生成大纲
      let outline = novel.outline;
      if (!outline) {
        console.log(`[Queue] Generating outline for novel ${novelId}`);
        await updateNovelStatus(novelId, "generating_outline");
        outline = await generateOutline(client, novel.title, novel.type);
        await updateNovelStatus(novelId, "generating_content", { outline });
      }

      // 2. 循环生成段落
      let currentContent = novel.content || "";
      let segments = currentContent ? currentContent.split("\n\n") : [];
      let totalChars = novel.totalChars || 0;

      while (totalChars < config.targetChars) {
        console.log(`[Queue] Generating segment ${segments.length + 1} for novel ${novelId} (${totalChars}/${config.targetChars} chars)`);
        const segment = await generateSegment(
          client,
          novel.title,
          outline!,
          segments,
          segments.length + 1,
          novel.type
        );

        segments.push(segment);
        currentContent = segments.join("\n\n");
        totalChars = currentContent.length;

        await updateNovelStatus(novelId, "generating_content", {
          content: currentContent,
          totalChars,
          currentSegment: segments.length
        });

        // 避免触发 API 频率限制
        await new Promise(resolve => setTimeout(resolve, 1500));
      }

      // 3. 完成任务
      console.log(`[Queue] Completed novel ${novelId}`);
      await updateNovelStatus(novelId, "completed");
      
      // 4. 更新批次进度
      if (novel.batchId) {
        const batch = await getBatchById(novel.batchId);
        if (batch) {
          await updateBatchStatus(novel.batchId, {
            completedCount: Number(batch.completedCount) + 1,
            status: Number(batch.completedCount) + 1 + Number(batch.failedCount) === Number(batch.totalCount) ? "completed" : "processing"
          });
        }
      }
    } catch (error) {
      console.error(`[Queue] Error processing novel ${novelId}:`, error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      await updateNovelStatus(novelId, "failed", { errorMessage });
      
      const novel = await getNovelById(novelId);
      if (novel?.batchId) {
        const batch = await getBatchById(novel.batchId);
        if (batch) {
          await updateBatchStatus(novel.batchId, {
            failedCount: Number(batch.failedCount) + 1,
            status: Number(batch.completedCount) + Number(batch.failedCount) + 1 === Number(batch.totalCount) ? "completed" : "processing"
          });
        }
      }
    }
  }
}
